globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5b1b8f9bd8f0faac.js",
    "static/chunks/112f346e31f991df.js",
    "static/chunks/18a5a133fb68ca26.js",
    "static/chunks/497f7b5edc7d3fce.js",
    "static/chunks/turbopack-dea158e87050dd39.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];