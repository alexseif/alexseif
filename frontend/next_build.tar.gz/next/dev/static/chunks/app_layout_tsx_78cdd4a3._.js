(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__3fd52a7f._.css",
  "static/chunks/node_modules_c7707855._.js"
],
    source: "dynamic"
});
