(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_79594151._.js",
  "static/chunks/node_modules_motion-dom_dist_es_3565adda._.js",
  "static/chunks/node_modules_framer-motion_dist_es_eef24521._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_b51e5974._.js"
],
    source: "dynamic"
});
